package usco.Parcial2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginPwApplicationTests {

	@Test
	void contextLoads() {
	}

}
