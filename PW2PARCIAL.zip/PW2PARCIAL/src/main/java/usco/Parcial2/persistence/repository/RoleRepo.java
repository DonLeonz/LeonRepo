package usco.Parcial2.persistence.repository;

import usco.Parcial2.persistence.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepo extends JpaRepository<Role, Long>{

}
