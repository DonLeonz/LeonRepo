package usco.Parcial2.persistence.repository;

import usco.Parcial2.persistence.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface StatusRepo extends JpaRepository<Status, Long>{

    @Query(value = "SELECT sub FROM Status sub WHERE sub.name = :name", nativeQuery = false)
    Status findByName(@Param("name") String name);

}
