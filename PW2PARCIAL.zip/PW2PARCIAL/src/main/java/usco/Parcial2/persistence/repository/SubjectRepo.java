package usco.Parcial2.persistence.repository;

import usco.Parcial2.persistence.entity.Subject;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface SubjectRepo extends JpaRepository<Subject, Long>{

    @Query(value = "SELECT s FROM Subject s WHERE s.teacher = :name", nativeQuery = false)
    List<Subject> findByTeacherName(@Param("name") String name);

    @Query(value = "SELECT s FROM Subject s WHERE s.teacher = :teacher AND s.schedule = :schedule", nativeQuery = false)
    Optional<Subject> findByTeacherAndSchedule(@Param("teacher") String teacher, @Param("schedule") Integer schedule);
}
