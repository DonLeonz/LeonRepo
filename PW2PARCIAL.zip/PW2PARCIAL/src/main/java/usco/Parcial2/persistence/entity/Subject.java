package usco.Parcial2.persistence.entity;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "subject")
public class Subject {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sub_id")
    private Long id;

    @NotNull
    @NotEmpty(message = "No puede estar vacía")
    @Size(max = 20, min = 3)
    @Pattern(regexp = "^(?!\\s*$).+", message = "No pueden ser espacios en blanco")
    @Column(name = "sub_name")
    private String name;

    @NotNull
    @Min(1)
    @Max(24)
    @Column(name = "sub_schedule")
    private Integer schedule;

    @NotNull
    @Size(max = 100)
    @Pattern(regexp = "^([A-Za-záéíóúÁÉÍÓÚñÑ]{3,}\\s){1,3}[A-Za-záéíóúÁÉÍÓÚñÑ]{3,}$", message = "El nombre y apellido deben tener al menos 3 letras cada uno, separados por un espacio.")
    @Column(name = "sub_teacher")
    private String teacher;

    @NotNull
    @Pattern(regexp = "^[a-zA-Z0-9-]+$", message = "Sólo valores alfanuméricos")
    @Column(name = "sub_classroom")
    private String classroom;

    @Valid
    @ManyToOne(cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH},
            fetch = FetchType.EAGER)
    @JoinColumn(name = "status_id")
    private Status status;

}
