package usco.Parcial2;

import usco.Parcial2.persistence.entity.Role;
import usco.Parcial2.persistence.entity.Status;
import usco.Parcial2.persistence.entity.UserEntity;
import usco.Parcial2.persistence.repository.StatusRepo;
import usco.Parcial2.persistence.repository.UserRepo;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	PasswordEncoder passwordEncoder;

	@Bean
	public CommandLineRunner init(UserRepo userRepo, StatusRepo staRepo) {
		return args -> {

			// Crear roles
			Role rectorRole = Role.builder()
					.name("RECTOR")
					.build();

			Role teacherRole = Role.builder()
					.name("TEACHER")
					.build();

			Role studentRole = Role.builder()
					.name("STUDENT")
					.build();

			Status programada = Status.builder()
					.name("Programada")
					.build();

			Status enCurso = Status.builder()
					.name("En Curso")
					.build();

			Status aplazada = Status.builder()
					.name("Aplazada")
					.build();

			Status cancelada = Status.builder()
					.name("Cancelada")
					.build();

			staRepo.saveAll(List.of(programada, enCurso, aplazada, cancelada));

			UserEntity rector = UserEntity.builder()
					.username("rector")
					.roles(Set.of(rectorRole))
					.password(passwordEncoder.encode("leon"))
					.build();

			UserEntity teacher = UserEntity.builder()
					.username("teacher")
					.roles(Set.of(teacherRole))
					.password(passwordEncoder.encode("leon"))
					.build();

			UserEntity student = UserEntity.builder()
					.username("teacher")
					.roles(Set.of(teacherRole))
					.password(passwordEncoder.encode("leon"))
					.build();


			userRepo.saveAll(List.of(rector, teacher));
		};
	}
}
