package usco.Parcial2.service;

import usco.Parcial2.persistence.entity.Subject;
import java.util.List;
import java.util.Optional;

public interface ISubjectService {

    List<Subject> findByTeacher(String name);

    Optional<Subject> findById(Long id);

    List<Subject> findAll();

    void save (Subject subjet);

    void delete (Long id);

    Optional<Subject> findByTeacherAndSchedule(String teacher, Integer schedule);
}