package usco.Parcial2.service.impl;

import usco.Parcial2.persistence.entity.Subject;
import usco.Parcial2.persistence.repository.StatusRepo;
import usco.Parcial2.persistence.repository.SubjectRepo;
import usco.Parcial2.service.ISubjectService;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SubjectService implements ISubjectService{

    @Autowired
    private SubjectRepo subjectRepo;

    @Autowired
    private StatusRepo statusRepo;

    @Override
    public List<Subject> findByTeacher(String name) {
        return subjectRepo.findByTeacherName(name);
    }

    @Override
    public Optional<Subject> findByTeacherAndSchedule(String teacher, Integer schedule) {
        return subjectRepo.findByTeacherAndSchedule(teacher, schedule);
    }

    @Override
    public Optional<Subject> findById(Long id) {
        return subjectRepo.findById(id);
    }

    @Override
    public List<Subject> findAll() {
        return subjectRepo.findAll();
    }

    @Override
    public void save(Subject subject) {

        subject.setStatus(statusRepo.findByName(subject.getStatus().getName()));
        subjectRepo.save(subject);
    }

    @Override
    public void delete(Long id) {
        subjectRepo.deleteById(id);
    }



}
