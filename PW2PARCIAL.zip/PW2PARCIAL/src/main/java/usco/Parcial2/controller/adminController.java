package usco.Parcial2.controller;

import usco.Parcial2.persistence.entity.Status;
import usco.Parcial2.persistence.entity.Subject;
import usco.Parcial2.persistence.repository.UserRepo;
import usco.Parcial2.service.impl.SubjectService;
import jakarta.validation.Valid;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/subject")
public class adminController {

    @Autowired
    SubjectService subService;

    @Autowired
    UserRepo userRepo;

    @GetMapping("/add")
    public String addSubject(Model model) {

        Subject newSub = new Subject();
        newSub.setStatus(new Status());

        model.addAttribute("newSub", newSub);
        model.addAttribute("valor", "Añadir");

        return "modifySubjectForm";
    }

    @PostMapping("/insert")
    public String insertSubject(@Valid @ModelAttribute("newSub") Subject subject, Errors error, Model model) {

        Optional<Subject> optionalSubject = subService.findByTeacherAndSchedule(subject.getTeacher(), subject.getSchedule());

        if (optionalSubject.isPresent()) {
            model.addAttribute("teacherError", "El profesor ya tiene una clase a esa hora");
            model.addAttribute("valor", subject.getId() == null ? "Añadir" : "Modificar");
            return "modifySubjectForm";
        }

        if (error.hasErrors()) {
            model.addAttribute("valor", subject.getId() == null ? "Añadir" : "Modificar");
            return "modifySubjectForm";
        } else {
            subService.save(subject);

            return "redirect:/subject/list";
        }
    }

    @GetMapping("/modify/{id}")
    public String modifyOwner(@PathVariable Long id, Model model) {

        Subject modSubject = subService.findById(id).orElse(null);

        model.addAttribute("newSub", modSubject);
        model.addAttribute("valor", "Modificar");
        return "modifySubjectForm";
    }

    @GetMapping("/delete/{id}")
    public String deleteOwner(@PathVariable Long id) {

        subService.delete(id);

        return "redirect:/subject/list";
    }

}