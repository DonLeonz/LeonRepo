package usco.Parcial2.controller;

import usco.Parcial2.persistence.entity.Subject;
import usco.Parcial2.persistence.entity.UserEntity;
import usco.Parcial2.persistence.repository.UserRepo;
import usco.Parcial2.service.impl.SubjectService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class userController {

    @Autowired
    SubjectService subService;

    @Autowired
    UserRepo userRepo;

    @GetMapping
    public String showIndex() {

        return "index";
    }

    @GetMapping("/subject/list")
    public String showSubjectList(Model model) {

        List<Subject> subjects = subService.findAll();

        model.addAttribute("subjects", subjects);
        return "subjectList";
    }

    @GetMapping("/loginPage")
    public String showLogin() {
        return "login";
    }

    @GetMapping("/teacher/list")
    public String listTeachers(Model model) {

        List<UserEntity> teachers = userRepo.findTeachers();

        model.addAttribute("teachers", teachers);
        return "teacherList";
    }
}